const dummyNotes = [
    {
      title: "Welcome to Notes, Nabilah!",
      body: "Welcome to Notes! This is your first note. You can archive it, delete it, or create new ones."
    },
    {
      title: "Meeting Agenda",
      body: "Discuss project updates and assign tasks for the upcoming week."
    },
    {
      title: "Shopping List",
      body: "Milk, Eggs, Croissant, Bananas, Vegetables."
    },
    {
      title: "Personal Goals",
      body: "Read two books per month, exercise three times a week, learn a new language."
    },
    {
      title: "Recipe: Spaghetti Bolognese",
      body: "Ingredients: ground beef, tomatoes, onions, garlic, pasta. Steps:..."
    },
    {
      title: "Workout Routine",
      body: "Monday: Cardio, Tuesday: Upper body, Wednesday: Rest, Thursday: Lower body, Friday: Cardio."
    },
    {
      title: "Book Recommendations",
      body: "1. 'The Alchemist' by Paulo Coelho\n2. '1984' by George Orwell\n3. 'To Kill a Mockingbird' by Harper Lee"
    },
    {
      title: "Travel Bucket List",
      body: "1. Singapore\n2. Kyoto, Japan\n3. Turkie\n4. New York City, USA"
    },
    {
      title: "Daily Reflections",
      body: "Write down three positive things that happened today and one thing to improve tomorrow."
    },
    {
      title: "Coding Projects",
      body: "1. Build a personal website\n2. Create a mobile app\n3. Contribute to an open-source project"
    },
    {
      title: "Holiday Plans",
      body: "Research and plan for the upcoming holiday destination."
    },
    {
      title: "Language Learning",
      body: "Practice Spanish vocabulary for 30 minutes every day."
    }
  ];
  
  export default dummyNotes;
  