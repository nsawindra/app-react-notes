import React, { useEffect, useState } from 'react';

const App = () => {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
      const data = await response.json();
      if (data.status === 'success') {
        setNotes(data.data);
      } else {
        setError('Gagal memuat catatan');
      }
    } catch (err) {
      setError('Terjadi kesalahan saat fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    try {
      const response = await fetch('https://notes-api.dicoding.dev/v2/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, body }),
      });
      const result = await response.json();

      if (result.status === 'success') {
        setTitle('');
        setBody('');
        fetchNotes();
      } else {
        alert('Gagal menambahkan catatan');
      }
    } catch (error) {
      alert('Terjadi kesalahan saat menambahkan catatan');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Yakin ingin menghapus catatan ini?')) return;
    try {
      await fetch(`https://notes-api.dicoding.dev/v2/notes/${id}`, {
        method: 'DELETE'
      });
      fetchNotes();
    } catch (error) {
      alert('Gagal menghapus catatan');
    }
  };

  const handleArchiveToggle = async (id, archived) => {
    const endpoint = archived ? 'unarchive' : 'archive';
    try {
      await fetch(`https://notes-api.dicoding.dev/v2/notes/${id}/${endpoint}`, {
        method: 'POST'
      });
      fetchNotes();
    } catch (error) {
      alert('Gagal mengubah status arsip');
    }
  };

  return (
    <div style={{ maxWidth: '720px', margin: '0 auto', padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '2rem' }}>📝 Notes App</h1>

      <form onSubmit={handleSubmit} style={{ marginBottom: '2rem', backgroundColor: '#f4f4f4', padding: '1.5rem', borderRadius: '10px' }}>
        <h2>Tambah Catatan Baru</h2>
        <input
          type="text"
          placeholder="Judul"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{ display: 'block', width: '100%', marginBottom: '0.75rem', padding: '0.75rem', borderRadius: '6px', border: '1px solid #ccc' }}
          required
        />
        <textarea
          placeholder="Isi catatan"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          style={{ display: 'block', width: '100%', height: '120px', padding: '0.75rem', borderRadius: '6px', border: '1px solid #ccc' }}
          required
        ></textarea>
        <button type="submit" style={{ marginTop: '1rem', padding: '0.6rem 1.5rem', border: 'none', backgroundColor: '#007bff', color: '#fff', borderRadius: '6px', cursor: 'pointer' }}>Tambah</button>
      </form>

      {loading && <p>⏳ Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {!loading && notes.length === 0 && <p>Tidak ada catatan ditemukan.</p>}

      {notes.map((note) => (
        <div
          key={note.id}
          style={{
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            borderRadius: '10px',
            padding: '1rem',
            marginBottom: '1.5rem',
            backgroundColor: note.archived ? '#e0e0e0' : '#ffffff',
          }}
        >
          <h3 style={{ marginTop: 0 }}>{note.title}</h3>
          <p>{note.body}</p>
          <div style={{ marginTop: '1rem' }}>
            <button
              onClick={() => handleArchiveToggle(note.id, note.archived)}
              style={{
                marginRight: '1rem',
                padding: '0.5rem 1rem',
                border: 'none',
                borderRadius: '6px',
                backgroundColor: '#28a745',
                color: '#fff',
                cursor: 'pointer'
              }}
            >
              {note.archived ? 'Aktifkan' : 'Arsipkan'}
            </button>
            <button
              onClick={() => handleDelete(note.id)}
              style={{
                padding: '0.5rem 1rem',
                border: 'none',
                borderRadius: '6px',
                backgroundColor: '#dc3545',
                color: '#fff',
                cursor: 'pointer'
              }}
            >
              Hapus
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default App;
