import React, { useEffect, useState } from 'react';

const App = () => {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  // Ambil catatan dari API
  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
      const data = await response.json();
      if (data.status === 'success') {
        setNotes(data.data);
      } else {
        setError('Gagal memuat catatan');
      }
    } catch (err) {
      setError('Terjadi kesalahan saat fetch data');
    } finally {
      setLoading(false);
    }
  };

  // Tambah catatan baru ke API
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    try {
      const response = await fetch('https://notes-api.dicoding.dev/v2/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, body }),
      });
      const result = await response.json();

      if (result.status === 'success') {
        setTitle('');
        setBody('');
        fetchNotes(); // refresh catatan
      } else {
        alert('Gagal menambahkan catatan');
      }
    } catch (error) {
      alert('Terjadi kesalahan saat menambahkan catatan');
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Notes App</h1>

      <form onSubmit={handleSubmit} style={{ marginBottom: '2rem' }}>
        <h2>Tambah Catatan Baru</h2>
        <input
          type="text"
          placeholder="Judul"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{ display: 'block', width: '100%', marginBottom: '0.5rem', padding: '0.5rem' }}
          required
        />
        <textarea
          placeholder="Isi catatan"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          style={{ display: 'block', width: '100%', height: '100px', padding: '0.5rem' }}
          required
        ></textarea>
        <button type="submit" style={{ marginTop: '1rem' }}>Tambah</button>
      </form>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {!loading && notes.length === 0 && <p>Tidak ada catatan ditemukan.</p>}

      {notes.map((note) => (
        <div
          key={note.id}
          style={{
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: '1rem',
            marginBottom: '1rem',
          }}
        >
          <h3>{note.title}</h3>
          <p>{note.body}</p>
        </div>
      ))}
    </div>
  );
};

export default App;
